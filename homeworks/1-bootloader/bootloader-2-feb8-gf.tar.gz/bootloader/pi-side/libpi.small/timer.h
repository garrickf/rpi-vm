void delay(unsigned ticks) ;
unsigned timer_get_time(void) ;
void delay_us(unsigned us) ;
void delay_ms(unsigned ms) ;

