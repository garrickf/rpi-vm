int set_tty_to_8n1(int fd, unsigned speed, double timeout);
