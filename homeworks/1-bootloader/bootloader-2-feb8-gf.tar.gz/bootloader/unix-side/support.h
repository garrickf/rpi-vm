// implement both of these for HW1.
unsigned char *read_file(int *size, const char *name);
int open_tty(const char **portname);
