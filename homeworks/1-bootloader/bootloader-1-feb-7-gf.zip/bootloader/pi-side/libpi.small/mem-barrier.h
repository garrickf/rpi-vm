void mb(void);
void dmb(void);
void dsb(void);
